create definer = root@localhost view my_view as
select `dt81`.`customs`.`NAME` AS `name`, `dt81`.`customs`.`sex` AS `sex`
from `dt81`.`customs`;

