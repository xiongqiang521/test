create
    definer = root@localhost procedure tool_sum()
begin
set @sum=0;
set @i=1;
for1: LOOP
	set @sum=@sum+@i;
	set @i=@i+2;

	IF @i>100 THEN
		LEAVE for1; 
	END IF; 
END LOOP for1;

select @sum;
end;

