create
    definer = root@localhost procedure sel_stuAndcount_byAge(IN age_start int, IN age_stop int, OUT stu_count int)
begin
	select * from student where age between age_start and age_stop;
	select COUNT(1) INTO stu_count from student where age between age_start and age_stop;
end;

