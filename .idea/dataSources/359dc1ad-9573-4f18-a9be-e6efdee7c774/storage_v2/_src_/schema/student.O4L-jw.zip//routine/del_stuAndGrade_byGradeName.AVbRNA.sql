create
    definer = root@localhost procedure del_stuAndGrade_byGradeName(IN gradeNameText char(12))
begin
	DELETE from student where idNum in (select idNum from grade where gradeName=gradeNameText);
	DELETE from grade where gradeName=gradeNameText;
end;

