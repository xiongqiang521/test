create view my_view as
select `student`.`student`.`id_student` AS `id_student`,
       `student`.`student`.`name`       AS `name`,
       `student`.`student`.`sex`        AS `sex`,
       `student`.`student`.`idNum`      AS `idNum`,
       `student`.`student`.`birthday`   AS `birthday`,
       `student`.`student`.`address`    AS `address`,
       `student`.`student`.`age`        AS `age`,
       `student`.`student`.`state`      AS `state`,
       `student`.`grade`.`gradeName`    AS `gradeName`
from (`student`.`student`
         join `student`.`grade` on ((`student`.`student`.`idNum` = `student`.`grade`.`idNum`)));

